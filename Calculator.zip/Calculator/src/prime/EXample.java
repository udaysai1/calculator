package prime;

public class EXample {
	public int Prime(int x) {
		int z=x%2;
		return z;
		
	}

}
