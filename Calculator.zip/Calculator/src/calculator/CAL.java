package calculator;

public class CAL {
	
	
	public int add(int x,int y)
	{
		int z=x+y;
		return z;
	}
	public int sub(int x,int y)
	{
		int z=x-y;
		return z;
	}

	public int mul(int x,int y)
	{
		int z=x*y;
		return z;
	}

	public int div(int x,int y)
	{
		int z=x/y;
		return z;
	}
	
	

	

}
